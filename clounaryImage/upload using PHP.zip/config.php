<?php 
\Cloudinary::config(array( 
  "cloud_name" => "dfao1egi1", 
  "api_key" => "727899366339817", 
  "api_secret" => "cckTCI-Ztt0E-JiMSCeDwX8fbYs" 
)); ?>